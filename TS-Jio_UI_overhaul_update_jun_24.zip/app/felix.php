<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tubes and Strips</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="tube">
    <div class="strip"></div>
    <div class="strip"></div>
    <div class="strip"></div>
    <!-- Repeat as many times as needed -->
  </div>
  <div class="tube">
    <div class="strip"></div>
    <div class="strip"></div>
    <div class="strip"></div>
    <!-- Repeat as many times as needed -->
  </div>
  <div class="tube">
    <div class="strip"></div>
    <div class="strip"></div>
    <div class="strip"></div>
    <!-- Repeat as many times as needed -->
  </div>
  <div class="tube">
    <div class="strip"></div>
    <div class="strip"></div>
    <div class="strip"></div>
    <!-- Repeat as many times as needed -->
  </div>
  <style>
    * {
  box-sizing: border-box;
  font-family: sans-serif;
}

body {
  --size: min(40vw, 40vh);
  --width: calc(var(--size) / 40);
  --dist: calc(var(--width) * 9.8);
  --count: 64;
  --bg: url('https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/5eeea355389655.59822ff824b72.gif');
  margin: 0;
  height: 100vh;
  width: 100%;
  background-image: linear-gradient(-45deg, #111, #222);
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--width);
}

.tube {
  transform-style: preserve-3d;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: speen 6s infinite linear;
  width: calc(var(--dist) * 2);
  height: var(--size);
}

.tube:nth-child(1) {
  animation-delay: -7.5s;
}

.tube:nth-child(2) {
  animation-delay: -5s;
}

.tube:nth-child(3) {
  animation-delay: -2.5s;
}

.strip {
  transform-style: preserve-3d;
  background-color: white;
  height: var(--size);
  width: var(--width);
  position: absolute;
  background-image: var(--bg);
  background-size: calc(var(--width) * var(--count)) auto;
  background-repeat: no-repeat;
  backface-visibility: hidden;
}

@for $i from 1 through 64 {
  .strip:nth-child(#{$i}) {
    transform: rotateY(calc(1turn * #{$i} / var(--count))) translateZ(var(--dist));
    background-position: calc(var(--width) * -#{$i - 1}) center;
  }
}

@keyframes speen {
  0% {
    transform: perspective(400px) rotateY(0deg);
  }
  100% {
    transform: perspective(400px) rotateY(360deg);
  }
}

  </style>
</body>
</html>
