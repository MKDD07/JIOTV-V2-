<?php

// * Copyright 2021-2024 SnehTV, Inc.
// * Licensed under MIT (https://github.com/mitthu786/TS-JioTV/blob/main/LICENSE)
// * Created By : TechieSneh

error_reporting(0);
$data = $_REQUEST["data"] ?? "";
$data = base64_decode($data);
$data = explode('=?=', $data);
$cid = $data[0] ?? "";
$id = $data[1] ?? "";
$name = strtoupper(str_replace('_', ' ', $cid));
$image = 'https://jiotv.catchup.cdn.jio.com/dare_images/images/' . $cid . '.png';
$c = $data[2] ?? "";

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$local_ip = getHostByName(php_uname('n'));
$ip_port = $_SERVER['SERVER_PORT'];
if ($_SERVER['SERVER_ADDR'] !== "127.0.0.1" && $_SERVER['SERVER_ADDR'] !== 'localhost') {
  $host_jio = $_SERVER['HTTP_HOST'];
} else {
  $host_jio = $local_ip;
}

$jio_path = $protocol . $host_jio  . str_replace(" ", "%20", str_replace(basename($_SERVER['PHP_SELF']), '', $_SERVER['PHP_SELF']));
$jio_path = substr($jio_path, 0, -1);


?>
<html>

<head>
  <title><?php echo $name; ?> | JioTV +</title>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="description" content="ENJOY FREE LIVE TV">
  <meta name="keywords" content="LIVETV, SPORTS, MOVIES, MUSIC">
  <meta name="author" content="TSNEH">
  <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="stylesheet" href="https://cdn.plyr.io/3.6.2/plyr.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
  <link rel="shortcut icon" type="image/x-icon" href="https://i.ibb.co/BcjC6R8/jiotv.png">
  <script src="https://cdn.plyr.io/3.6.3/plyr.js"></script>
  <script type="text/javascript" src="https://content.jwplatform.com/libraries/IDzF9Zmk.js"></script>
  <link rel="stylesheet" href="assets/css/techiesneh.min.css">
  <link rel="stylesheet" href="assets/css/search.css">
</head>

<body>
  <header>
    <div id="jtvh1">
      <a href="http://localhost/index.php">
        <img src="assets/main_assets/main_logo.png" alt="JIOTV+">
      </a>
    </div>
    <div id="userButtons">
      <button id="logoutButton">Logout</button>
      <button id="refreshButton">
        <img src="assets/main_assets/reload.svg" alt="Refresh">
      </button>
    </div>
  </header>
  <br/>
  <div class="channel_logo" style="text-align: center;">
  <img src="<?php echo $image; ?>" alt="Logo" width="100px" height="auto" style="margin: 0 auto 0 50px; display: block;" />
  <div id="player-container"></div>

<script>
    // Function to parse URL parameters
    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    // Extract video file path from URL parameter
    var videoFilePath = getParameterByName('data');
    
    // Initialize JWPlayer
    var player = jwplayer("player-container");

    // Set up configuration options
    player.setup({
        file: videoFilePath,
        width: "100%",
        aspectratio: "16:9", // Adjust as needed
        autostart: true, // Or false if you don't want auto-play
        // Add more configuration options as needed
    });
</script>
      <?php
    $cp_link_live = $cid . '=?=' . $id;
    $cp_link_live = base64_encode($cp_link_live);
    ?>
    <hr style="width: 95%; margin: 0 auto; border-color: #fff;">
  </div>
  <br/>
  <?php if ($c == "y") {
    $cp_link_live = $cid . '=?=' . $id;
    $cp_link_live = base64_encode($cp_link_live);
    echo <<<GFG
    <div class="card-container">
    <div class="grouped-elements" style="display: inline-block; position: relative; border: 1px solid #BA3B46; border-radius: 8px;">
        <a href="$jio_path/play.php?data=$cp_link_live" class="btn btn-danger" style="background-color: transparent; padding: 9px 21px; height:40px; text-decoration: none;">LIVE</a>
    </div>
    GFG;
    for ($i = 0; $i >= -7; $i--) {
      $cp_link = $cid . '=?=' . $id . '=?=' . $i;
      $cp_link = base64_encode($cp_link);

      $currentDate = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
      $prevDate = clone $currentDate;
      $prevDate->modify("$i day");

      echo <<<GFG
        <img class="card-img-top" src="$image" alt="logo" width="20px">
        <a href="$jio_path/catchup/cp.php?data=$cp_link" class="btn btn-primary">{$prevDate->format('d-m-Y')}</a>
      GFG;
    }
    echo <<<GFG
  </div>
  GFG;
  }
  if ($c == "n") {
    $cp_link_live = $cid . '=?=' . $id;
    $cp_link_live = base64_encode($cp_link_live);
    echo <<<GFG
  <div class="card-container">
    <div class="red_card">
      <h2 id="jtvh1"> OOPS !! CATCHUP NOT AVAILABLE </h2>
    </div>
  </div>
  GFG;
  }
  ?>
  <br/>
  <script src="assets/js/details.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
  <style>
   #userButtons {
  font-size: 14px;
  font-family: fantasy;
  text-align-last: center;
}
.btn-danger {
  border: none;
  color: #BA3B46; /* Set default button text color */
}

.grouped-elements:hover {
  background-color: #BA3B46; /* Red background color on hover */
  color: #fff; /* White text color on hover */
}

.btn-danger:hover {
  color: #fff; /* White text color for button on hover */
}

.circle {
  background-color: #BA3B46; /* Circle default background color */
}

.circle:hover {
  background-color: #fff; /* Circle background color on hover */
}

.grouped-elements:hover .circle {
  display: none; /* Hide circle on hover */
}
    @import url("https://cdn.jsdelivr.net/npm/@fontsource/holtwood-one-sc@4.5.1/index.min.css");
    @import url("https://fonts.googleapis.com/css?family=Montserrat:300,400,700,800");

    #jtvh1 {
    text-align: center;
    font-size: 25px;
    margin: 15px;
    padding-bottom: 10px;
    font-family: 'Roboto', sans-serif; /* Updated to use Roboto */
    background-color: rgb(255, 255, 255);
    background-image: rgb(255, 255, 255);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

    #jtvh1 img {
      width: 250px;
      height:100px;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      color: #fff;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: row;
        align-items: center;
        text-align: center;
      }
    }

    body {
      background-color: #232528;
      /* color: #fff; */
      font-family: sans-serif;
      font-size: 16px;
      margin: 0;
      padding: 0;
    }

    /* Cards */
    .card-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      gap: 20px;
    }

    .red_card {
      width: 250px;
      height: 250px;
      background-color: #ff000000;
      border-radius: 10px;
      padding: 20px;
      box-sizing: border-box;
      text-align: center;
    }

    .card {
      width: 250px;
      height: 250px;
      background-color: none;
      border-radius: 10px;
      padding: 20px;
      box-sizing: border-box;
      text-align: center;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .card {
        width: 150px;
        height: 150px;
      }
    }
    img{
      width:150px;
      height:auto;
    }
    .card-img-top{
      display:none;
    }
    .btn-primary {
    box-sizing: border-box;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;
    align-content: center;
    padding: 13px 32px;
    gap: 10px;
    width: auto;
    height: 40px;
    border: 0.5px solid #FFFFFF;
    border-radius: 8px;
    font-family: 'Roboto', sans-serif;
    font-style: normal;
    font-weight: 200;
    font-size: 16px;
    line-height: 20px;
    letter-spacing: 0.4px;
    text-transform: uppercase;
    color: #FFFFFF;
    background: none;
}

.btn-primary:hover,
.btn-primary:active {
    background: #fff;
    color: #232528; /* Corrected from font-color */
    border-color: #232528; /* Change border color on hover and active */
}

  </style>
</body>
</html>